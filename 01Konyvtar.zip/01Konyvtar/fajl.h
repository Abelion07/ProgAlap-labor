#ifndef INC_01KONYVTAR_FAJL_H
#define INC_01KONYVTAR_FAJL_H

void fajl_beolvasas(void);

#endif //INC_01KONYVTAR_FAJL_H
