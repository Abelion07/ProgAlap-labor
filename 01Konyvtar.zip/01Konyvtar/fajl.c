#include <stdio.h>

void fajl_beolvasas(void) {
    FILE *f = fopen("konyvek.csv", "r");

    if (f == NULL) {
        printf("Nem sikerult megnyitni a fajlt.\n");
        return;
    }

    char sor[512];

    while (fgets(sor, sizeof(sor), f) != NULL) {
        printf("%s", sor);
    }

    fclose(f);
}