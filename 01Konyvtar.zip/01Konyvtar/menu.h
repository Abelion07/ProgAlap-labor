#ifndef INC_01KONYVTAR_MENU_H
#define INC_01KONYVTAR_MENU_H

void fomenu(void);

#endif
