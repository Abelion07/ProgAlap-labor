#include <stdio.h>

#include "menu.h"

int main() {
    fomenu();

    return 0;
}
