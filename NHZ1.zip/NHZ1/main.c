#include <stdio.h>

void feladat1(void);

int main() {
    feladat1(void);
    return 0;
}